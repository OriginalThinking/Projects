from sys import *
import json, random, socket, time, csv, multiprocessing, datetime
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

#Variables
interval = 0
num = 0
country = ""
idt = 0
host = ""
bw = 0

#User input validation - Infinite loop while conditions aren't met
while(True):
	if len(argv) != 4 or (not argv[1].isdigit()) or (not argv[2].isdigit()):
		print("""Use like: python3 client.py interval(in seconds) num [country or id]""")
		x = input("Interval(in seconds):")#Temporary interval
		y = input("Number of tests: ")#Temporary number of tests
		z = input("Country name or id: ")#Temporary country or id
		if(x.isdigit() and y.isdigit() and int(x)>0 and int(y)>0):
			if(z.isdigit() and int(z)> 0):
				interval = int(x)
				num = int(y)
				idt = int(z)
				break
			elif(z != ""):
				interval = int(x)
				num = int(y)
				country = z
				break 
	else:
		interval = int(argv[1])
		num = int(argv[2])
		if argv[3].isdigit() and int(argv[3]) > 0:
			idt = int(argv[3])
		else:
			country = argv[3]
		break
				
#creating readble file from json document
servers_dic = []
with open('servers.json', 'r') as f:
    servers_dict = json.load(f)
    servers_dic = servers_dict["servers"]
    
#list (and it's counter) to store servers hosts , when input is 
#a country name, so later we can choose a host randommly from that same list.
#Also,lists were created so we can store the name, country, id, and sponsor
#of each server so we can print them when server is chossen
server_list_hosts = []
server_list_name = []
server_list_country = []
server_list_sponsor = []
server_list_id = []

#file reader and host retriver
for server in servers_dic:
    if server["id"] == idt:
        host = server["host"]
        print("""Server Found!---|
		|--> Name: %s
		|--> Country: %s
		|--> Sponsor: %s
		|--> Id: %d""" % (server["name"], server["country"], server["sponsor"], idt))
        break
    elif server["country"] == country:
        server_list_hosts.append(server["host"])
        server_list_name.append(server["name"])
        server_list_country.append(server["country"])
        server_list_sponsor.append(server["sponsor"])
        server_list_id.append(server["id"])
else:
	if len(server_list_hosts) == 0:
		print ("Server not found")
		exit()

#Host random chooser from 'server_list'
if idt == 0 and len(server_list_hosts) != 0:
	x = random.randint(1,len(server_list_hosts)-1)
	host = server_list_hosts[x]
	idt = server_list_id[x]
	print("""Server Chossen:---|
	\t  |--> Name: %s
	\t  |--> Country: %s
	\t  |--> Sponsor: %s
	\t  |--> Id: %d
		  |--> Host: %s\n""" % (server_list_name[x], server_list_country[x], server_list_sponsor[x], idt, host))

#Store host adress and hot adress port
host_adress, port = host.split(":")
host_port = int(port)

#Info to store in CSV form
counter_csv = []
id_serv_csv = []
date_csv = []
lat_csv = []
bw_csv = []
chk_csv= []

#Pinging function
def ping():
	t = 0
	e = 0
	x = 0
	while(x < num):
		try:
			#Creating a ("channel") socket and connecting to socket
			ch = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			ch.connect((host_adress,host_port))

			#Send HELLO to server
			ch.send(("HI\n").encode("utf-8"))
			rp = (ch.recv(1024)).decode("utf-8")
			print("""Sendig "HI\\n" to server...\nServer: """ + rp + "\nPinging...\n")
		
			#Pinging
			while(x < num):
				dif = 0
				print("Test %d\n" % (x+1))
				for i in range(10):
					start = int(time.time()*1000)
					ch.send((("PING {}\n").format(start).encode("utf-8")))
					r = (ch.recv(1024)).decode("utf-8")
					print(r)
					end = int(time.time()*1000)
					dif += (end-start)
				counter_csv.append((x+1))
				id_serv_csv.append(idt)
				date_csv.append(datetime.datetime.utcnow().isoformat())
				lat_csv.append((dif/10)) 	
				x += 1
				time.sleep(interval)
			
			#When number of pings hit the number of teste entended, socket is close and pinging loop is broken
			#this time outside loop is broken because pinging test has ended			
			if(x == num):
				ch.close()
				break 
				
		#catching error if socket get's closed, waiting and retrying		
		except socket.timeout:
			print("Socket lost! Creating new connection...\n  ")
			t += 1
			if ( t == 3):
				counter_csv.append(0)
				id_serv_csv.append(idt)
				date_csv.append(datetime.datetime.utcnow().isoformat())
				lat_csv.append(-1)
				print("Giving up pinging, going for download...\n")
				break
		#catching error if socket can't connect, waiting and retrying
		except socket.error:
			print("Couldn't connect, trying new connection...\n")
			e += 1
			if ( e == 3 ):
				counter_csv.append(0)
				id_serv_csv.append(idt)
				date_csv.append(datetime.datetime.utcnow().isoformat())
				lat_csv.append(-1)
				print("Giving up pinging, going for download...\n")
				break

#Downloading funciton
def download():
	t = 0
	e = 0
	x = 0 
	while(True):
		try:
			#Creating socket and connecting
			ch = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			ch.connect((host_adress,host_port))
		
			#Send HELLO to server
			ch.send(("HI\n").encode("utf-8"))
			rp = (ch.recv(1024)).decode("utf-8")
			x = random.randint(10240,102400)	#Download size randomizer between 10MBs and 100MBs
			print("""\nSendig "HI\\n" to server...\nServer: """ + rp + "\nDownloading %dMB/s...\n" % ((x/1024)))
			
			#Downloading 1 KB at a time, 10240 time over so it downloads 21MB
			start = 0
			end = 0
			for y in range(x): 										
				ch.send((("DOWNLOAD {}\n").format(1024)).encode("utf-8"))	#Sending and receiving 1 KB (1024 bytes) at a time
				r = (ch.recv(1024)).decode("utf-8")
				if(y == 1024):
					print("1 MB Downloaded, counter started now!")
					start = time.time()										#Start recording time
				if(y == x):
					end = time.time()
					dif = end - start
					bw = (x/1024) / dif												#End recording time	and claculate diference 							
					print("""Details:---|\n\t   |--> Bandwidth of: %d MB/s""" % (bw))					
				x += 1
			
			#End tests, close socket and 'jump out' if there is no error until here
			ch.send(("QUIT\n").encode("utf-8"))
			ch.close();
			break
			
		#catching error if socket get's closed, waiting and retrying
		except socket.timeout:
			print("Socket lost! Creating new connection...\n  ")
			t += 1
			if ( t == 3):
				bw_csv.append(bw)
				print("Giving up downloading\n")
				break
		#catching error if socket can't connect, waiting and retrying
		except socket.error:
			print("Couldn't connect, trying new connection...\n")
			t += 1
			if ( t == 3):
				bw_csv.append(bw)
				print("Giving up downloading\n")
				break
				
#Calling the test function
ping()

#Calling the download function with a timeout of 10 seconds
if __name__ == '__main__':
	p = multiprocessing.Process(target=download)
	p.start()
	p.join(10)
	if p.is_alive():
		print("\nDownload overextended 10 seconds, stoping download...\n")
		p.terminate()		
		for i in counter_csv:
			bw_csv.append(bw)
		p.terminate()
	else:
		i = 0
		while i < len(counter_csv):
			bw_csv.append(bw)
			i += 1
	p.join()
	
time.sleep(2)
print("Creating CSV File...")
time.sleep(2)	

#Creating check list
i = 0
while i < len(counter_csv):
	chk_csv.append(str(counter_csv[i])+str(id_serv_csv[i])+str(date_csv[i])+str(lat_csv[i])+str(bw_csv[i]))
	i += 1
#list to write to CSV file
data_csv = []
data_csv.append(["counter", "id", "date", "latency", "bandwidth", "check"]) 
for i in range(len(counter_csv)):
	data_csv.append([str(counter_csv[i]),str(id_serv_csv[i]),str(date_csv[i]),str(lat_csv[i]),str(bw_csv[i]),str(chk_csv[i])])

#CSV File Writer
Results = open('results.csv', 'w')
with Results:
	writer = csv.writer(Results)
	writer.writerows(data_csv)
print("CSV file created!\n")

#Encryption
key = RSA.generate( 1024 )
fout = open( "key.priv", "wb" )
kp = key.exportKey( "PEM", "senha" )
fout.write(kp)
fout.close()

f = open( "key.priv", "rb" )
keypair = RSA.importKey( f.read(), "senha" )
cipher = PKCS1_OAEP.new( keypair )
with open("report.sig", "wb") as file:
	with open("results.csv", "r") as ori :
		for line in ori.read():
			file.write(cipher.encrypt(line.encode("utf-8")))

print("Congratulations!\nTests successfully run and CSV file created\nClosing program...")
time.sleep(2)
exit()
