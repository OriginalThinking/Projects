import java.util.*;
import java.io.*;

public class ListRec{

	public static void main(String[] args){
		listDir(new File(args[0]));
	}
	public static void listDir(File in){
		
		if(in.isDirectory()){
			System.out.println(in.getPath());
			File[] cnt = in.listFiles();
			for( int w = 0; w < cnt.length; w++){
				listDir(cnt[w]);
			}
		}if(in.isFile()){
			System.out.println(in.getPath());
		}
	}
}
