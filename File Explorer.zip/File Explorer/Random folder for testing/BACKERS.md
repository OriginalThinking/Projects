# Bountysource Backers

Thank you to everyone who backed our [Bountysource fundraiser](https://www.bountysource.com/teams/crystal-lang/fundraiser)!

### Your name and URL in BACKERS.md.

- Adam Daniels, https://github.com/adam12
- Bo Jeanes, http://bjeanes.com/
- Bruno Antunes, https://github.com/sardaukar
- gottlike, https://github.com/gottlike
- Hirofumi Wakasugi, https://github.com/5t111111
- Jean-Baptiste Barth, http://jbbarth.com/
- jhp
- Kris Leech, http://teamcoding.com/
- Luis Lavena, http://blog.mmediasys.com/
- Sb
- Scott Fleckenstein, https://about.me/nullstyle
- Serdar Dogruyol, http://www.serdardogruyol.com/
- Sergey Kucher, https://github.com/sergey-kucher
- Simon George, http://www.sfcgeorge.co.uk/about
- Yukihiro "Matz" Matsumoto, https://github.com/matz

### Your name in BACKERS.md.

- Ashley Towns
- Ben Miller
- benoist
- Dor Kalev
- Hayashida Ryuichi
- Jesse Doyle
- Joakim Ekström
- Jonne Haß
- Joseph Method
- Keiji Matsuzaki
- marcpmichel
- rhoeft
- Ryan Worl
- schaarw
- Sergio Gil
- Shannon Skipper
- Sho Kusano
